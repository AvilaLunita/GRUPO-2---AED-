package Arreglos;

import Clases.Alquiler;


public class ArregloAlquiler {
    
    private Alquiler[] alquileres;
    private int indice;

    // Constructor que inicializa el arreglo con un tamaño inicial
    public ArregloAlquiler(int capacidadInicial) {
        alquileres = new Alquiler[capacidadInicial];
        indice = 0;
    }

    // Método para obtener el número actual de alquileres en el arreglo
    public int getIndice() {
        return indice;
    }

    // Método para agregar un nuevo alquiler
    public void add(Alquiler obj) {
        if (indice >= alquileres.length) {
            // Si el arreglo está lleno, se duplica el tamaño
            expandirCapacidad();
        }
        alquileres[indice] = obj;
        indice++;
    }

    // Método para buscar alquileres según un criterio y un valor
    public Alquiler[] buscarAlquiler(String criterio, String valor) {
        Alquiler[] resultados = new Alquiler[indice];
        int contador = 0;

        for (int i = 0; i < indice; i++) {
            Alquiler alquiler = alquileres[i];
            if (alquiler != null) {
                switch (criterio) {
                    case "Hubicacion":
                        if (alquiler.getHubicacion().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "InicioHora":
                        if (alquiler.getInicioHora().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "FinHora":
                        if (alquiler.getFinHora().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "TipoCoche":
                        if (alquiler.getTipoCoche().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "Capacidad":
                        if (alquiler.getCapacidad().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "Equipaje":
                        if (alquiler.getEquipaje().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "Transmision":
                        if (alquiler.getTransmision().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                    case "TipoPago":
                        if (alquiler.getTipoPago().equals(valor)) {
                            resultados[contador++] = alquiler;
                        }
                        break;
                }
            }
        }
        
        // Ajustar el tamaño del arreglo de resultados
        Alquiler[] encontrados = new Alquiler[contador];
        System.arraycopy(resultados, 0, encontrados, 0, contador);
        return encontrados;
    }

    // Método para obtener todos los alquileres
    public Alquiler[] obtenerTodosLosAlquileres() {
        Alquiler[] copia = new Alquiler[indice];
        System.arraycopy(alquileres, 0, copia, 0, indice);
        return copia;
    }

    // Método para expandir la capacidad del arreglo cuando está lleno
    private void expandirCapacidad() {
        Alquiler[] nuevoArreglo = new Alquiler[alquileres.length * 2];
        System.arraycopy(alquileres, 0, nuevoArreglo, 0, alquileres.length);
        alquileres = nuevoArreglo;
    }
}

