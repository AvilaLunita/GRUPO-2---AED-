package GUI;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class FrmAlquiler extends javax.swing.JFrame {
    
    FondoPanel fondo = new FondoPanel ();
    
    private String dato ;
    private DefaultTableModel modeloTabla;

    public FrmAlquiler() {
        this.setContentPane(fondo);
        initComponents();
        inicializarModeloTabla(); 
    }
    
    private void inicializarModeloTabla() {
    modeloTabla = new DefaultTableModel(
        new Object[][]{}, // Datos iniciales vacíos
        new String[]{"Ubicacion", "Inicio/Hora", "Fin/Hora", "Tipo Vehiculo", "Capacidad", "Equipaje", "Transmision", "Tipo Pago"}
    );
    jTable1.setModel(modeloTabla);
}
    
    public void setDato (String dato) {
        this.dato = dato ;
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new FondoPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtUbicacion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        CInicio = new com.toedter.calendar.JDateChooser();
        CFin = new com.toedter.calendar.JDateChooser();
        ComboBoxTV = new javax.swing.JComboBox<>();
        ComboBoxC = new javax.swing.JComboBox<>();
        ComboBoxT = new javax.swing.JComboBox<>();
        ComboBoxTP = new javax.swing.JComboBox<>();
        CheckBoxE = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Lista = new FondoPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        btnOrdenar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnListar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("UBICACION:");

        jLabel2.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("INICIO/HORA");

        jLabel3.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("FIN/HORA");

        txtUbicacion.setFont(new java.awt.Font("Bodoni MT", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TIPO DE VEHICULO:");

        jLabel5.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TIPO DE PAGO:");

        jLabel6.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("CAPACIDAD:");

        jLabel7.setFont(new java.awt.Font("Cooper Black", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("TRANSMISION:");

        ComboBoxTV.setFont(new java.awt.Font("Bodoni MT", 0, 12)); // NOI18N
        ComboBoxTV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "Pequeño", "Mediano", "Grande", "Todo Terreno", "Lujo" }));

        ComboBoxC.setFont(new java.awt.Font("Bodoni MT", 0, 12)); // NOI18N
        ComboBoxC.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "1 - 2 ", "1- 4", "4 - 6", "8 - 12", "12 - 18" }));

        ComboBoxT.setFont(new java.awt.Font("Bodoni MT", 0, 12)); // NOI18N
        ComboBoxT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "Automatico", "Manual" }));

        ComboBoxTP.setFont(new java.awt.Font("Bodoni MT", 0, 12)); // NOI18N
        ComboBoxTP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "Tarjeta", "Visa", "CTR", "Yape / Plin" }));

        CheckBoxE.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        CheckBoxE.setForeground(new java.awt.Color(255, 255, 255));
        CheckBoxE.setText("Equipaje");
        CheckBoxE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckBoxEActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        jButton1.setText("RESERVAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        jButton2.setText("ALQUILAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel7)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ComboBoxT, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ComboBoxTP, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 30, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtUbicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ComboBoxC, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ComboBoxTV, 0, 109, Short.MAX_VALUE))
                                .addGap(20, 20, 20)))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(jLabel2)
                        .addGap(51, 51, 51)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1)
                                .addGap(29, 29, 29))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CheckBoxE, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2)
                            .addComponent(CFin, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(175, 175, 175)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(89, 89, 89)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(ComboBoxTV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(txtUbicacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ComboBoxC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CheckBoxE))
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ComboBoxT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ComboBoxTP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(87, 87, 87))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton1))
                        .addGap(43, 43, 43))))
        );

        jTabbedPane1.addTab("Registro", jPanel1);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Ubicacion", "Inicio/Hora", "Fin/Hora", "Tipo Vehiculo", "Capacidad", "Equipaje", "Transmision ", "Tipo Pago"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btnBuscar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnOrdenar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnOrdenar.setText("ORDENAR");
        btnOrdenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrdenarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnListar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnListar.setText("LISTAR");
        btnListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Cambria", 0, 16)); // NOI18N
        btnModificar.setText("MODIFICAR");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ListaLayout = new javax.swing.GroupLayout(Lista);
        Lista.setLayout(ListaLayout);
        ListaLayout.setHorizontalGroup(
            ListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ListaLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(btnBuscar)
                .addGap(26, 26, 26)
                .addComponent(btnOrdenar)
                .addGap(18, 18, 18)
                .addComponent(btnModificar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAgregar)
                .addGap(18, 18, 18)
                .addComponent(btnListar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addGap(44, 44, 44))
            .addGroup(ListaLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 767, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );
        ListaLayout.setVerticalGroup(
            ListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ListaLayout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addGroup(ListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminar)
                    .addComponent(btnListar)
                    .addComponent(btnAgregar)
                    .addComponent(btnOrdenar)
                    .addComponent(btnBuscar)
                    .addComponent(btnModificar))
                .addGap(51, 51, 51)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(269, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Lista", Lista);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 834, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CheckBoxEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckBoxEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CheckBoxEActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String ubicacion = txtUbicacion.getText();
        Date fechaInicio = CInicio.getDate();
        Date fechaFin = CFin.getDate();
        String tipoVehiculo = (String) ComboBoxTV.getSelectedItem();
        String capacidad = (String) ComboBoxC.getSelectedItem();
        boolean equipaje = CheckBoxE.isSelected();
        String transmision = (String) ComboBoxT.getSelectedItem();
        String tipoPago = (String) ComboBoxTP.getSelectedItem();

        if (ubicacion.isEmpty() || fechaInicio == null || fechaFin == null) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // Crear una fila con los datos recolectados
        Object[] fila = {
            ubicacion,
            fechaInicio,
            fechaFin,
            tipoVehiculo,
            capacidad,
            equipaje ? "Sí" : "No", // Convertir boolean a texto para la tabla
            transmision,
            tipoPago
        };

        // Agregar la fila al modelo de la tabla
        modeloTabla.addRow(fila);
        limpiarFormulario();
        jTabbedPane1.setSelectedComponent(Lista);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String terminoBusqueda = JOptionPane.showInputDialog(this, "Ingrese el término de búsqueda:");
                if (terminoBusqueda != null && !terminoBusqueda.trim().isEmpty()) {
                    BusquedaSecuencial(terminoBusqueda);
                }
            }
        });

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Agregar();
            }
        });
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        btnModificar.addActionListener(new java.awt.event.ActionListener() { // Supongo que el botón es "ORDENAR/MODIFICAR"
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Modificar();
            }
        });

    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        btnEliminar.addActionListener(new java.awt.event.ActionListener() { // Supongo que el botón es "ORDENAR/MODIFICAR"
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Eliminar();
            }
        });

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdenarActionPerformed
        btnOrdenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                // Opciones de las columnas disponibles en la tabla
                String[] opciones = {
                    "Ubicacion", // Columna 0
                    "Inicio/Hora", // Columna 1
                    "Fin/Hora", // Columna 2
                    "Tipo Vehiculo", // Columna 3
                    "Capacidad", // Columna 4
                    "Equipaje", // Columna 5
                    "Transmision", // Columna 6
                    "Tipo Pago" // Columna 7
                };

        // Mostrar un cuadro de diálogo para seleccionar la columna
        int columna = JOptionPane.showOptionDialog(
            FrmAlquiler.this,               // Contexto del JFrame
            "Seleccione la columna por la que desea ordenar:", // Mensaje
            "Ordenar",                      // Título del cuadro de diálogo
            JOptionPane.DEFAULT_OPTION,     // Tipo de opción
            JOptionPane.INFORMATION_MESSAGE,// Tipo de mensaje
            null,                           // Icono, null si no se desea un icono
            opciones,                       // Opciones disponibles
            opciones[0]                     // Opción por defecto seleccionada
        );

        // Si el usuario selecciona una opción válida (columna >= 0)
                if (columna >= 0) {
                    OrdenarBurbuja(columna);  // Llama al método de ordenamiento burbuja para la columna seleccionada
                    JOptionPane.showMessageDialog(
                            FrmAlquiler.this,
                            "Registros ordenados correctamente por " + opciones[columna] + "."
                    );
                }
            }
        });


    }//GEN-LAST:event_btnOrdenarActionPerformed

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnListarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmAlquiler().setVisible(true);
            }
        });
    }

    private void BusquedaSecuencial(String terminoBusqueda) {
        boolean encontrado = false;

        // Itera a través de todas las filas de la tabla
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            // Recorre cada columna de la fila para buscar coincidencias
            for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
                Object valorCelda = modeloTabla.getValueAt(i, j);
                if (valorCelda != null && valorCelda.toString().toLowerCase().contains(terminoBusqueda.toLowerCase())) {
                    // Si se encuentra una coincidencia, selecciona la fila en la tabla
                    jTable1.setRowSelectionInterval(i, i);
                    encontrado = true;
                    break; // Rompe el ciclo interno si se encuentra una coincidencia
                }
            }
            if (encontrado) {
                break; // Rompe el ciclo externo si ya se encontró la coincidencia
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "No se encontraron coincidencias.", "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void OrdenarBurbuja(int columna) {
        int n = modeloTabla.getRowCount();
        boolean intercambioRealizado;

        // Implementación del algoritmo de burbuja
        do {
            intercambioRealizado = false;

            for (int i = 0; i < n - 1; i++) {
                // Obtener los valores actuales y el siguiente para comparación
                Object valorActual = modeloTabla.getValueAt(i, columna);
                Object valorSiguiente = modeloTabla.getValueAt(i + 1, columna);

                if (valorActual != null && valorSiguiente != null) {
                    // Comparar y cambiar si es necesario (orden ascendente)
                    if (valorActual.toString().compareTo(valorSiguiente.toString()) > 0) {
                        // Intercambiar las filas completas
                        intercambiarFilas(i, i + 1);
                        intercambioRealizado = true;
                    }
                }
            }
        } while (intercambioRealizado);
    }

    private void intercambiarFilas(int fila1, int fila2) {
        // Intercambia los valores de dos filas en el modelo de la tabla
        for (int columna = 0; columna < modeloTabla.getColumnCount(); columna++) {
            Object temp = modeloTabla.getValueAt(fila1, columna);
            modeloTabla.setValueAt(modeloTabla.getValueAt(fila2, columna), fila1, columna);
            modeloTabla.setValueAt(temp, fila2, columna);
        }
    }

    private void Agregar() {
        String ubicacion = txtUbicacion.getText();
        Date fechaInicio = CInicio.getDate();
        Date fechaFin = CFin.getDate();
        String tipoVehiculo = (String) ComboBoxTV.getSelectedItem();
        String capacidad = (String) ComboBoxC.getSelectedItem();
        boolean equipaje = CheckBoxE.isSelected();
        String transmision = (String) ComboBoxT.getSelectedItem();
        String tipoPago = (String) ComboBoxTP.getSelectedItem();

        // Validaciones básicas
        if (ubicacion.isEmpty() || fechaInicio == null || fechaFin == null) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear una fila y agregarla al modelo de la tabla
        Object[] fila = {
            ubicacion,
            fechaInicio,
            fechaFin,
            tipoVehiculo,
            capacidad,
            equipaje ? "Sí" : "No",
            transmision,
            tipoPago
        };

        modeloTabla.addRow(fila); // Agregar la fila al modelo de la tabla
        JOptionPane.showMessageDialog(this, "Registro agregado exitosamente.");

        // Limpiar campos
        limpiarFormulario();
    }

    private void limpiarFormulario() {
        txtUbicacion.setText("");
        CInicio.setDate(null);
        CFin.setDate(null);
        ComboBoxTV.setSelectedIndex(0);
        ComboBoxC.setSelectedIndex(0);
        CheckBoxE.setSelected(false);
        ComboBoxT.setSelectedIndex(0);
        ComboBoxTP.setSelectedIndex(0);
    }

    
    private void Modificar() {
        int filaSeleccionada = jTable1.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Reemplaza los valores en la fila seleccionada con los datos actuales del formulario
        modeloTabla.setValueAt(txtUbicacion.getText(), filaSeleccionada, 0);
        modeloTabla.setValueAt(CInicio.getDate(), filaSeleccionada, 1);
        modeloTabla.setValueAt(CFin.getDate(), filaSeleccionada, 2);
        modeloTabla.setValueAt(ComboBoxTV.getSelectedItem(), filaSeleccionada, 3);
        modeloTabla.setValueAt(ComboBoxC.getSelectedItem(), filaSeleccionada, 4);
        modeloTabla.setValueAt(CheckBoxE.isSelected() ? "Sí" : "No", filaSeleccionada, 5);
        modeloTabla.setValueAt(ComboBoxT.getSelectedItem(), filaSeleccionada, 6);
        modeloTabla.setValueAt(ComboBoxTP.getSelectedItem(), filaSeleccionada, 7);

        JOptionPane.showMessageDialog(this, "Registro modificado exitosamente.");
    }

    private void Eliminar() {
        int filaSeleccionada = jTable1.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        modeloTabla.removeRow(filaSeleccionada); // Eliminar la fila del modelo de la tabla
        JOptionPane.showMessageDialog(this, "Registro eliminado exitosamente.");
    }

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser CFin;
    private com.toedter.calendar.JDateChooser CInicio;
    private javax.swing.JCheckBox CheckBoxE;
    private javax.swing.JComboBox<String> ComboBoxC;
    private javax.swing.JComboBox<String> ComboBoxT;
    private javax.swing.JComboBox<String> ComboBoxTP;
    private javax.swing.JComboBox<String> ComboBoxTV;
    private javax.swing.JPanel Lista;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnOrdenar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtUbicacion;
    // End of variables declaration//GEN-END:variables


    class FondoPanel extends JPanel
    {
    private Image imagen;
    
    @Override
    public void paint (Graphics g)
            
    {
        imagen = new ImageIcon(getClass().getResource("/imagenes/ALQUILERPORTADA.JPG")).getImage();
        g.drawImage(imagen,0,0,getWidth(), getHeight(), this);
        setOpaque(false);
        super.paint(g);
    }
   }






}

