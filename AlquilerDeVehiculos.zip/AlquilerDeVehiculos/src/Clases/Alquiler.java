package Clases;

public class Alquiler {

    private String Hubicacion;
    private String InicioHora;
    private String FinHora;
    private String TipoCoche;
    private String Capacidad;
    private String Equipaje;
    private String Transmision;
    private String TipoPago;
 
    public String getHubicacion() {
        return Hubicacion;
    }

    public void setHubicacion(String Hubicacion) {
        this.Hubicacion = Hubicacion;
    }

    public String getInicioHora() {
        return InicioHora;
    }

    public void setInicioHora(String InicioHora) {
        this.InicioHora = InicioHora;
    }

    public String getFinHora() {
        return FinHora;
    }

    public void setFinHora(String FinHora) {
        this.FinHora = FinHora;
    }

    public String getTipoCoche() {
        return TipoCoche;
    }

    public void setTipoCoche(String TipoCoche) {
        this.TipoCoche = TipoCoche;
    }

    public String getCapacidad() {
        return Capacidad;
    }

    public void setCapacidad(String Capacidad) {
        this.Capacidad = Capacidad;
    }

    public String getEquipaje() {
        return Equipaje;
    }

    public void setEquipaje(String Equipaje) {
        this.Equipaje = Equipaje;
    }

    public String getTransmision() {
        return Transmision;
    }

    public void setTransmision(String Transmision) {
        this.Transmision = Transmision;
    }

    public String getTipoPago() {
        return TipoPago;
    }

    public void setTipoPago(String TipoPago) {
        this.TipoPago = TipoPago;
    }

}
