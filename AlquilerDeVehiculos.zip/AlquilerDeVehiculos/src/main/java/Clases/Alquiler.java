package Clases;

public class Alquiler {

    private String FechaInicio;
    private String FechaFin;
    private String campoLaboral;
    private String duracion;

    public String getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(String FechaInicio) {
        this.FechaInicio = FechaInicio;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String FechaFin) {
        this.FechaFin = FechaFin;
    }

    public String getCampoLaboral() {
        return campoLaboral;
    }

    public void setCampoLaboral(String campoLaboral) {
        this.campoLaboral = campoLaboral;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    
}
